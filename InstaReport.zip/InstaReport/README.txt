ABOUT THIS TOOL

Insta Report Is a tool which reports a targeted instagram account. 
It uses multi threading, therefore it reports very fast. 
This tool is strongly recommended for educational purpose.


HOW TO USE?

Follow the steps to use this tool : 

WINDOWS

1. Open cmd in the tool directary folder
2. Install python 3
3. Run "pip install -r requirements.txt"
4. Run "python reportbot.pyc"

ANDROID (Termux)

1. cd path name of tool
2. install python
3. Run "pip install -r requirements.txt" 
4. Run "python reportbot.pyc"


ABOUT AUTHOR 

Hey, I am crevil. This tool is codded by me. 
You can contact me on telegram at @hacker_exploits
My telegram channel @hackerExploits Where i do giveaway 
of many hacking tools/exploits.
Join Us On telegram @HackerExploits For More Such Hacking Tools/Exploits